# Community-aware ranking v3

## Почему это не копия одного раздела Fragrantica

ScentMatch использует crowd data как свидетельство, а не как абсолютную истину.
Запах субъективен, поэтому в ranking независимо входят:

1. fine-tuned multilingual E5 — смысл свободного запроса;
2. structured intent и hard constraints;
3. community votes: season, day/night, longevity, sillage, perceived gender;
4. `reminds_me_of` — прямое голосование «пахнет похоже / не похоже»;
5. `also_liked` — вкусовая близость, которая не означает одинаковый запах;
6. Bayesian rating и popularity с recent/compound engagement;
7. diversity control.

Для `reminds_me_of` используется сглаженная agreement-оценка и reliability по
числу голосов. Ребро с двумя голосами не может конкурировать с подтверждённой
связью. Обратные ребра тоже учитываются, но с меньшим весом.

## Query-dependent weights

У системы нет одной формулы для всех запросов. Запрос без референса начинает с
semantic E5 + Bayesian quality и добавляет только явно запрошенные оси. Запрос
`похож на X` активирует отдельные `reference_content`, `reminds_me_of` и
`also_liked`. Веса нормализуются только среди доступных сигналов и выводятся в
CLI для аудита.

Сезонность сглаживается глобальным prior:

```text
(season_votes + alpha * global_season_prior) / (all_season_votes + alpha)
```

Если у аромата не меньше 30 сезонных голосов и меньше 10% приходится на явно
запрошенный сезон, кандидат исключается. Это защищает запрос «на лето» от
тяжёлых зимних ароматов, не объявляя сезон объективным свойством запаха.

## Community perception

В `community_summary` сохранены source-provided AI summaries, но только вместе
с up/down votes пользователей. Тезис используется как объяснение, если доля
согласия не ниже 60% и есть не меньше пяти голосов. Это не обучающая разметка и
не заменяет исходные отзывы.

Старый max-similarity reranker по Persian review chunks выключен. Фраза
`слишком тяжёлый летом` семантически похожа на запрос про лето, но имеет
отрицательную полярность. Следующий NLP-эксперимент должен извлекать
`aspect + value + polarity + evidence`, а не искать самый похожий целый отзыв.

## Репрезентативная оценка и ML

`ranking_queries_v3.jsonl` содержит 48 запросов по сезонам, occasions,
performance, exclusions, attributes, popularity, разным референсам, сложным и
неопределённым запросам. Это не gold labels. Для честной оценки нужно:

1. получить top-10 baseline v0.2 и hybrid v0.3;
2. объединить кандидатов и скрыть название системы;
3. вручную поставить relevance 0–3, constraint violation и evidence quality;
4. измерить nDCG@5, Precision@5, violations, coverage, Gini и hub exposure;
5. сохранить dev/test split до подбора весов.

После 300–500 ручных judgments эти признаки становятся датасетом для
learning-to-rank. Первая ML-модель — pairwise LightGBM LambdaRank на CPU;
эвристические веса остаются baseline. Модель принимается только если улучшает
test nDCG и не ухудшает hard constraints, diversity и группы запросов. Так ML
учится смешивать измеримые сигналы, а не генерирует неподтверждённые названия.

## Лицензия и provenance

Community данные получены из Le Decanteur — Fragrantica Perfumes v2,
CC BY-NC-SA 4.0. Проект и производные данные предназначены для некоммерческого
портфолио. `community_profiles_v2_report.json` содержит хеш исходного dump,
coverage и число связей.
