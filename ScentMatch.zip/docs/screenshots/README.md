# Portfolio screenshot checklist

Only capture results from the real fine-tuned model and runtime artifacts.

Status: all three portfolio screenshots have been captured and added to
`docs/images/`.

## Preparation

```powershell
scentmatch-app
```

Open `http://127.0.0.1:8000/app` in Microsoft Edge or Chrome at 100% zoom. Use a
window around 1440×900 and avoid showing local usernames, unrelated tabs or
terminal history. On Windows, `Win+Shift+S` opens Snipping Tool; save each
capture with the exact filename below.

## Required screenshots

### `docs/images/demo_reference.png`

Query:

```text
Популярный несладкий мужской аромат похожий на Versace Pour Homme
```

Include the parsed preferences, reference and at least the first two explained
recommendations. This screenshot demonstrates the distinctive reference-aware
graph path, not merely the basic semantic search.

### `docs/images/demo_constraints.png`

Query:

```text
Стойкий свежий аромат на лето без сильного шлейфа
```

Show the explanation reasons and the community limitation notice.

### `docs/images/api_docs.png`

Open `http://127.0.0.1:8000/docs`, expand `POST /api/v1/recommend`, select
**Try it out**, submit a real query and capture the endpoint with the successful
`200` response visible. The committed capture uses the affordable autumn query
to expose the parsed `budget_mode` in the response. Do not include a local
filesystem path or any unrelated browser information.

## Capture rules

- use PNG;
- keep text readable without zooming;
- do not crop away the ScentMatch heading;
- do not edit recommendation names or scores;
- do not use mock or manually composed results;
- keep each file below approximately 1.5 MB when possible.

A terminal screenshot of the benchmark is not required. The committed JSON and
Markdown report are more readable, reproducible and useful to reviewers.

After the images are added, place the reference screenshot near the top of both
README files and the other two in the Demo/API sections.
