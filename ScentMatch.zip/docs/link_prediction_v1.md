# Community similarity link prediction v1

## Задача

Ручная оценка большого каталога невозможна для пользователя, который не знает
большинство ароматов. Поэтому reference-рекомендации оцениваются как offline
link-prediction задача: восстановить скрытую подтверждённую связь
`reminds_me_of`, не используя её в признаках.

## Labels

После объединения направлений в неориентированные пары:

- positive: не менее 10 голосов, agreement ≥ 0.70;
- negative: не менее 10 голосов, agreement ≤ 0.40;
- пары между порогами не используются;
- отсутствующие пары не считаются negatives.

Получено 1 372 positives и 4 508 explicit negatives. Split выполняется
детерминированным hash пары 70/15/15. Поэтому `(A, B)` и `(B, A)` не могут
оказаться в разных частях.

## Признаки

- fine-tuned E5 cosine;
- Jaccard нот и аккордов;
- cosine интенсивностей аккордов;
- близость season и day/night votes;
- сходство longevity, sillage и rating;
- popularity percentiles;
- `also_liked`;
- common-neighbor Jaccard и Adamic–Adar только по positive train graph.

Node degree был удалён: первая модель получила высокие цифры, но ablation
показал hub bias. После удаления degree dev macro pairwise accuracy выросла с
0.789 до 0.947. Это решение принято до просмотра итоговых test-метрик.

## Модель

StandardScaler + LogisticRegression с `C=0.1` и balanced class weights.
Коэффициенты и параметры scaler сохраняются как JSON. Inference использует
NumPy и не зависит от версии pickle/joblib или scikit-learn.

## Результаты

| Метрика | Dev | Test |
| --- | ---: | ---: |
| ROC-AUC | 0.840 | 0.883 |
| Average Precision | 0.756 | 0.790 |
| E5 macro pairwise accuracy | 0.803 | 0.709 |
| ML macro pairwise accuracy | 0.947 | 0.894 |
| E5 top-1 positive rate | 0.800 | 0.688 |
| ML top-1 positive rate | 0.938 | 0.896 |

Pairwise ranking сравнивает для одного reference все доступные positive и
explicit-negative test edges. Test включает 96 reference-групп и 158
positive-vs-negative сравнений. Это меньше human evaluation, поэтому модель
подключается консервативно и только как один из сигналов.

## Ограничения

- community voters не являются случайной выборкой пользователей;
- explicit-negative pairs появляются только после nomination и голосования;
- модель оценивает community similarity, а не личный вкус нового пользователя;
- для свободных запросов без reference эта модель не применяется;
- online feedback и expert evaluation всё ещё нужны для продуктового качества.
