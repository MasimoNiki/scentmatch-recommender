# Reference and community-signal retrieval

## What this stage adds

`scentmatch-search` now supports three complementary signals:

1. The fine-tuned multilingual E5 embedding of the full query.
2. The catalog embedding of a perfume explicitly named in Russian or English text.
3. Deterministic constraints: excluded notes, compatible gender and a budget filter.

For a query such as `аромат похожий на Bleu de Chanel, но бюджетнее`, the query
vector is a normalized mixture of 80% reference-perfume vector and 20% full-query
vector. The reference itself is removed from results.

## Community data

The Aromo augmentation contains aggregated notes perceived by users and a market
segment. These fields are useful crowd signals, but they are **not prose reviews**.
The current conservative exact normalized brand-and-name join produced:

- 3,056 catalog profiles with at least one community signal;
- 2,419 profiles with community-perceived notes;
- 2,371 profiles with a segment.

Source: [Aromo.ru Fragrance Dataset](https://www.kaggle.com/datasets/olgagmiufana1/aromo-ru-fragrance-dataset/data),
CC BY-NC 4.0.

## Price data and limitations

The optional price filter uses the
[Perfume E-Commerce Dataset 2024](https://www.kaggle.com/datasets/kanchana1990/perfume-e-commerce-dataset-2024),
not live store prices. Matching is intentionally conservative; ambiguous listings,
samples, vials, minis and formats smaller than 30 ml are discarded. This leaves 221
catalog perfumes with a historical price signal.

These values should be interpreted only as evidence that one listing was cheaper in
May 2024. They are unsuitable for displaying a current retail price. A production
version should connect to a current and legally usable retailer feed.

## English support

The named-perfume resolver keeps Latin names unchanged and works inside either
Russian or English text. Single-word names are treated conservatively: without a
brand, they require an explicit phrase such as `similar to` or `похож на`. This
prevents `no vanilla` from being mistaken for a perfume named Vanilla.

Explicit exclusions are bilingual:

- Russian: `без ванили`, `без табака`;
- English: `no vanilla`, `without tobacco`.

The automated test suite covers bilingual reference resolution, both budget-intent
languages, ambiguity removal, small-format price removal and exclusions.

## Next review-text experiment

The next experiment should be isolated from the current trusted catalog:

1. Obtain a legally reusable dataset with actual review text and stable perfume IDs.
2. Store reviews as a separate one-to-many table, not inside the base profile.
3. Embed review chunks and aggregate their scores per perfume.
4. Compare `catalog only` against `catalog + community notes` and `catalog + reviews`.
5. Keep the review branch only if it improves a bilingual human-judged test set.

This avoids presenting aggregated notes as reviews and keeps the project small.
