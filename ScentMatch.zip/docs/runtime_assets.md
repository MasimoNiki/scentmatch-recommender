# Runtime assets

The source repository stays small and reviewable. Large or derived inference
assets are installed separately and validated before the application starts.

## Required layout

Run `scentmatch-runtime-check` from the repository root. A complete local demo
requires:

```text
data/processed/perfume_profiles_5000.jsonl
data/augmentation/community_profiles_v2.jsonl
data/augmentation/community_signals.jsonl
data/augmentation/price_snapshot_2024.jsonl
artifacts/e5_finetuned/document_embeddings.npy
artifacts/e5_finetuned/metadata.json
artifacts/link_predictor_v1/model.json
models/e5_finetuned/config.json
models/e5_finetuned/modules.json
models/e5_finetuned/*.safetensors
```

The command exits non-zero and prints every missing path. Docker Compose runs
the same validation during image construction.

## What belongs in Git

Small evidence files are explicitly allowed by `.gitignore`:

- E5 metadata;
- the portable link-predictor JSON;
- final benchmark JSON and Markdown reports;
- evaluation queries and documentation.

Model weights, document embeddings and the derived 5,000-item catalogue stay
outside normal Git history. This avoids an opaque, oversized clone while
keeping the evaluation claims inspectable.

## Portfolio release options

For a public portfolio, choose one of these after checking the licenses of every
included asset:

1. attach a versioned runtime archive to a GitHub Release and document its
   checksum;
2. publish the fine-tuned model and embeddings in a model registry and add a
   deterministic download command;
3. keep the assets local and publish real UI/API screenshots plus the hardware
   benchmark report.

The current repository uses option 3 until redistribution terms and a stable
download location are confirmed. Do not publish source-derived data or model
weights merely because they are technically easy to archive. Preserve dataset
attribution and the non-commercial/share-alike constraints described in the
main README.
