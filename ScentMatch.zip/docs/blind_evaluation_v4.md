# Blind evaluation v4 and perception retrieval

## Зачем нужен этот этап

Качество v0.3 неоднородно: community graph силён для `похож на X`, а свободные
описания всё ещё сильно зависят от E5 и вручную заданных весов. Изменение весов
по нескольким примерам создаёт selection bias. v0.4 поэтому не подменяет
evaluation очередной эвристикой.

## Три независимых варианта

1. `semantic` — embedding запроса с общими hard constraints.
2. `community` — текущий v0.3: season/performance/popularity, reference graph и
   diversity.
3. `perception` — v0.3 плюс 12% statement-level similarity к голосованным
   community descriptions.

В публичном пуле названия систем, score и позиции скрываются. Один аромат,
предложенный несколькими системами, показывается только один раз. Secret
manifest сохраняет provenance и используется только после разметки.

## Community text signal

Источник содержит AI-сводки `pros/cons`, но каждый тезис имеет up/down votes.
Индекс принимает тезис только при:

- не менее 5 голосов;
- Wilson lower bound не ниже 0.60;
- не более 3 pros и 2 cons на аромат.

Все принятые тезисы кодируются fine-tuned multilingual E5 как отдельные
passages. Для запроса выбирается самый близкий тезис каждого аромата, а score
ослабляется при малом числе голосов. `pro/cons` не трактуется как объективная
полярность свойства: это источник evidence, а не автоматическая gold label.

## Разметка

Каждая пара `query × perfume` получает:

- relevance 0–3;
- нарушение явного ограничения;
- evidence quality 0–2;
- `unknown`, если оценщик не знает аромат достаточно хорошо.

Случаи `unknown` не используются в метриках и обучении. Это важнее полного
покрытия: принудительные случайные labels делают Learning-to-Rank хуже.

## Защита от подгонки

- 48 запросов охватывают 9 категорий и заранее разделены на dev/test;
- параметры меняются только по dev;
- test открывается после фиксации модели;
- результаты сравниваются по nDCG@5, Precision@5, constraint violations,
  category slices, coverage и exposure;
- модель не принимается, если среднее выросло за счёт провала отдельной группы.

После 300–500 осмысленных labels следующий этап — CPU-friendly LambdaMART.
В признаки войдут E5, structured/community axes, reference graph, perception
similarity, popularity, quality и позиции систем. Hard constraints останутся
до ML-ranker, а diversity — после него.
