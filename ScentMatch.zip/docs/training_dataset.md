# Synthetic training data and hard negatives v1

## Состав

- 2 000 train-запросов;
- 200 validation-запросов;
- 2 200 разных positive-парфюмов;
- 3 hard negatives на запрос, всего 6 600;
- четыре равные группы запросов: `note`, `accord`, `combo`, `negation`.

Evaluation-запросы `q001`–`q040` не используются при генерации или обучении.
Positive ID между train и validation не пересекаются.

## Hard-negative mining

Запросы кодируются frozen baseline `intfloat/multilingual-e5-small`. Из верхних
результатов выбираются ароматы, которые нарушают явное условие:

- отсутствует обязательная нота;
- присутствует запрещённая нота;
- отсутствует требуемый аккорд.

Средняя cosine similarity positive — 0,7984, hard negative — 0,8249. В 99,4%
пар negative находится выше positive, поэтому набор действительно содержит
ошибки текущей модели.

ML-ready файлы содержат только текстовые столбцы `anchor`, `positive`,
`negative_1`, `negative_2`, `negative_3`. ID, scores, rank и причина выбора
хранятся отдельно в `triplets_provenance_v1.jsonl`.

## Ограничения

Это автоматически полученные silver-данные. Они хорошо обучают модель явным
нотам, аккордам и отрицаниям, но не заменяют реальные пользовательские вкусы.
После fine-tuning сравниваются неизменные `dev/test` proxy-метрики и несколько
результатов просматриваются вручную.

## Fine-tuning

В `notebooks/finetune_e5_colab.ipynb` находится готовый Colab workflow. Он
использует `MultipleNegativesRankingLoss`, explicit hard negatives и
`BatchSamplers.NO_DUPLICATES`.
