# ScentMatch

ML/NLP-проект для поиска подходящих ароматов по текстовому описанию
предпочтений пользователя. Текущая версия включает CPU-baseline на
`intfloat/multilingual-e5-small`, структурированный `QueryIntent` и
устойчивое к опечаткам разрешение названий ароматов и community-aware ranking.

Реализованы подготовка данных, evaluation, hard-negative mining, fine-tuning
`multilingual-e5-small`, сравнение моделей, локальный hybrid inference,
evaluation v2 для intent parsing и reference resolution, а также гибридный
ranking v0.3 на community votes и пользовательском графе сходства, blind
evaluation v0.4 и leakage-safe link prediction v0.5.

## Текущий этап v0.6: API, demo UI и проверяемые объяснения

v0.6 превращает исследовательский pipeline в единый демонстрационный сервис.
CLI, FastAPI и Gradio используют один загруженный `RecommendationService`,
поэтому результаты не расходятся между интерфейсами, а модель и индексы не
загружаются заново на каждый запрос.

Объяснения создаются без LLM. `ExplanationGenerator` показывает только сигналы,
которые действительно присутствовали в результате ranking: semantic match,
community similarity, link prediction, сезон, стойкость, шлейф, сладость,
популярность и явные предпочтения. Неподтверждённый сигнал не может попасть в
текст объяснения.

Установка полного приложения:

```powershell
python -m pip install -e ".[dev,ml,app]"
```

Запуск API и интерфейса одной командой:

```powershell
scentmatch-app
```

После загрузки модели:

- интерфейс: http://127.0.0.1:8000/app;
- Swagger API: http://127.0.0.1:8000/docs;
- health check: http://127.0.0.1:8000/health.

Только API без Gradio:

```powershell
scentmatch-api
```

Пример запроса:

```powershell
$body = @{
    query = "Популярный несладкий мужской аромат на лето похожий на Versace Pour Homme"
    top_k = 5
} | ConvertTo-Json

Invoke-RestMethod `
    -Method Post `
    -Uri http://127.0.0.1:8000/api/v1/recommend `
    -ContentType "application/json" `
    -Body $body
```

Контракт и ограничения объяснений описаны в
[`api_and_explanations_v06.md`](api_and_explanations_v06.md).

## Текущий этап v0.5

Ручная blind-разметка v0.4 сохранена как инструмент для будущих экспертов, но
больше не является обязательным этапом: владелец проекта не должен оценивать
незнакомые ароматы.

v0.5 обучает переносимую logistic link-prediction модель на community votes:

- positive — `reminds_me_of` с минимум 10 голосами и agreement не ниже 70%;
- negative — только показанные пользователям пары с минимум 10 голосами и
  agreement не выше 40%;
- отсутствие ребра не считается отрицательной меткой;
- прямые и обратные записи объединяются до train/dev/test split;
- dev/test edges отсутствуют в common-neighbor features;
- node degree исключён после dev ablation из-за hub bias;
- параметры модели экспортируются в JSON, inference не требует scikit-learn.

На фиксированном test split:

```text
ROC-AUC:                         0.883
Average Precision:              0.790
E5 macro pairwise accuracy:     0.709
ML macro pairwise accuracy:     0.894
E5 top-1 positive rate:         0.688
ML top-1 positive rate:         0.896
```

ML-score включается только для запросов `похож на X` и получает небольшой вес.
Текущий reference search:

```powershell
scentmatch-search "Похожий на Versace Pour Homme, но менее очевидный"
```

Сравнение без ML-сигнала:

```powershell
scentmatch-search "Похожий на Versace Pour Homme" --no-link-model
```

Воспроизвести обучение и offline evaluation:

```powershell
scentmatch-train-link
```

## Текущий эксперимент v0.4

v0.4 не меняет основной v0.3 ranker без доказательств. Вместо подбора весов по
отдельным удачным или неудачным примерам он сравнивает вслепую три системы:

- semantic E5 baseline;
- hybrid community ranker v0.3;
- экспериментальный perception-aware ranker.

`scentmatch-community-text` строит statement-level индекс из 3 надёжных `pros`
и 2 `cons` на аромат. В индекс попадают только community-тезисы с минимум пятью
голосами и Wilson lower bound не ниже 0.60. E5 сопоставляет русскоязычный запрос
с англоязычными описаниями того, как аромат ощущается пользователями.

Perception score имеет только 12% в экспериментальном варианте и пока не
используется командой `scentmatch-search`. Решение о включении будет принято по
human-judged test split.

Одноразовая подготовка и слепая оценка:

```powershell
scentmatch-community-text --model models/e5_finetuned
scentmatch-blind-eval generate
start artifacts\evaluation_v4\judging_v4.html
```

Страница не использует сервер и сохраняет промежуточные ответы в браузере.
Для незнакомого аромата следует выбрать «Не знаю этот аромат», а не ставить
случайную оценку. После скачивания `judgments_v4.jsonl`:

```powershell
scentmatch-blind-eval analyze `
  --judgments "$env:USERPROFILE\Downloads\judgments_v4.jsonl"
```

Команда создаст отдельный отчёт по системам и
`data/training/ltr_judgments_v1.jsonl`. Обучение ranker разрешается после 300
осмысленных оценок; `unknown` в train не попадает.

## Реализованный этап v0.3

- прежняя система зафиксирована в
  `docs/baseline_v1_manifest.json` вместе с SHA-256 и proxy-метриками;
- `scentmatch-parse-intent` извлекает пол, сезон, повод, ноты, исключения,
  сладость, популярность, доступность, стойкость, шлейф, бюджет и референс;
- reference resolver использует полный name + brand, fuzzy matching,
  confidence/margin и отказ при неоднозначности;
- CLI применяет явный gender, exclusions и надёжные community gates;
- сезон, day/night, longevity, sillage, интенсивность сладкого аккорда и
  popularity участвуют в query-dependent ranking;
- пользовательский граф содержит `reminds_me_of` с up/down votes и
  `also_liked`; слабые и спорные связи получают малый вес;
- E5 остаётся ML-сигналом, но не может перебить явное сезонное несоответствие;
- MMR-style diversity не позволяет нескольким почти одинаковым ароматам или
  одному бренду захватывать top-5;
- review similarity по персидским отзывам теперь выключен по умолчанию до
  появления aspect + polarity extraction;
- `scentmatch-eval-v2` отдельно измеряет intent parsing и entity resolution.
- `data/eval/ranking_queries_v3.jsonl` содержит 48 репрезентативных запросов для
  будущего human-judged A/B и обучения learning-to-rank.

Пример с исходной ошибкой:

```powershell
scentmatch-parse-intent "Нужен популярный несладкий мужской парфюм похожий на Vercahe Pour homme"
```

Resolver выбирает `Versace Pour Homme — Versace`, а не
`Homme — David Beckham`. Для одного общего слова `Homme` он отказывается
угадывать.

## Датасет

Источник — Kaggle **Fragrantica.com Fragrance Dataset**:

- https://www.kaggle.com/datasets/olgagmiufana1/fragrantica-com-fragrance-dataset;
- происхождение: web scraping сайта Fragrantica.com;
- заявленная на Kaggle лицензия: CC BY-NC-SA 4.0;
- `fra_cleaned.csv`: 24 063 структурированных профиля;
- `fra_perfumes.csv`: 70 103 записи с описаниями.

Проект предназначен для некоммерческого исследования и портфолио. Ограничения
источника описаны в [`dataset_decision.md`](dataset_decision.md).

Community profile v2 построен из
[Le Decanteur — Fragrantica Perfumes](https://www.kaggle.com/datasets/ledecanteur/fragrantica-perfumes),
версия 2, CC BY-NC-SA 4.0. Исходный dump содержит 131 930 ароматов; все 5 000
профилей ScentMatch сопоставились по стабильному Fragrantica ID. В компактном
файле проекта сохранены только выбранные профили и связи внутри каталога.

## Структура

```text
data/raw/          # исходные CSV и manifest
data/interim/      # отчёты валидации и EDA
data/processed/    # отобранный каталог и perfume profiles
docs/              # решения по данным и описание форматов
schemas/           # JSON Schema perfume_profile
src/scentmatch/    # Python-пакет и консольные команды
tests/             # автоматические тесты
```

## Установка на Windows 10

Нужен Python 3.11 или новее. В терминале PyCharm из корня проекта:

```powershell
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -e ".[dev]"
```

Если `.venv` уже создана, достаточно активировать её и повторить последнюю
команду: так зарегистрируются новые команды проекта.

## Полный конвейер данных

В приложенном архиве CSV уже присутствуют, поэтому загрузку можно пропустить:

```powershell
scentmatch-validate
scentmatch-eda
scentmatch-select
scentmatch-audit
scentmatch-eval-validate
scentmatch-silver-label
scentmatch-e5 evaluate
scentmatch-generate-train
scentmatch-mine-negatives
scentmatch-compare
```

Если исходных CSV нет, сначала выполните:

```powershell
scentmatch-download
```

Результаты:

- `data/interim/fragrantica_validation.json` — проверка исходных файлов;
- `data/interim/eda_summary.json` — машиночитаемая статистика;
- `data/interim/eda_report.md` — короткий отчёт EDA;
- `data/processed/perfume_profiles_5000.jsonl` — основной набор профилей;
- `data/processed/perfume_catalog_5000.csv` — тот же набор для просмотра;
- `data/processed/selection_report.json` — правила и итог отбора.
- `data/interim/profile_audit.json` — машиночитаемый аудит 5 000 профилей;
- `data/interim/profile_audit.md` — краткие выводы аудита.
- `data/eval/queries_v1.jsonl` — 40 запросов будущего retrieval evaluation;
- `data/interim/eval_validation.json` — проверка структуры запросов;
- `data/interim/eval_queries_review.csv` — плоская копия для ручного просмотра;
- `data/eval/silver_qrels_v1.jsonl` — автоматические proxy-оценки релевантности;
- `artifacts/e5_small/document_embeddings.npy` — embeddings 5 000 ароматов;
- `data/interim/e5_baseline_report.json` — baseline-метрики;
- `data/interim/e5_results_review.csv` — топ-5 для необязательного просмотра;
- `data/training/train_triplets_v1.jsonl` — 2 000 ML-ready train n-tuples;
- `data/training/validation_triplets_v1.jsonl` — 200 validation n-tuples;
- `data/training/triplets_provenance_v1.jsonl` — ID, scores и причины negatives;
- `data/interim/training_triplets_review.csv` — 50 примеров для необязательного
  просмотра.
- `models/e5_finetuned/` — fine-tuned модель;
- `artifacts/e5_finetuned/document_embeddings.npy` — её embeddings каталога;
- `data/interim/e5_finetuned_hybrid_report.json` — итоговые proxy-метрики;
- `data/interim/model_comparison_hybrid.csv` — изменения по каждому запросу.
- `data/augmentation/community_profiles_v2.jsonl` — community votes,
  performance, popularity, consensus evidence и similarity graph для 5 000
  профилей;
- `data/interim/community_profiles_v2_report.json` — coverage и provenance;
- `data/eval/ranking_queries_v3.jsonl` — 48 запросов по 9 категориям;
- `schemas/ranking_judgment_v3.schema.json` — шкала ручной оценки 0–3.
- `artifacts/community_text_v1/` — локально строящийся индекс голосованных
  community statements;
- `artifacts/evaluation_v4/judging_v4.html` — автономный интерфейс слепой
  оценки;
- `schemas/ranking_judgment_v4.schema.json` — шкала с честным вариантом
  `unknown`.

Отбор детально описан в
[`selection_strategy.md`](selection_strategy.md), формат записи — в
[`perfume_profile.md`](perfume_profile.md).
Решение по итогам проверки качества зафиксировано в
[`data_quality_decision.md`](data_quality_decision.md).

## Проверка проекта

```powershell
pytest
ruff check .
scentmatch-eval-v2
```

Для текущего regression-набора ожидается:

```text
QueryIntent: 18/18 cases, field accuracy = 1.00
Reference resolver: Top-1 = 1.00, abstain accuracy = 1.00
All quality gates passed = true
```

Эти значения проверяют только размеченные случаи intent parsing и entity
resolution. Они не являются оценкой релевантности рекомендаций.

Ожидаемый результат `scentmatch-select` для текущего снимка данных:

```text
Selection completed.
Selected profiles: 5000
Eligible pool: 13680
```

Протокол и шкала релевантности описаны в
[`evaluation_protocol.md`](evaluation_protocol.md), baseline — в
[`e5_baseline.md`](e5_baseline.md). Метрики относительно silver labels
являются proxy-оценками, а не заменой человеческой оценки предпочтений.
Итоги обучения находятся в
[`fine_tuning_results.md`](fine_tuning_results.md).

Для ML-команд установите дополнительные зависимости:

```powershell
python -m pip install -e ".[dev,ml]"
```

Локальный поиск:

```powershell
scentmatch-search "Ищу свежий цитрусовый аромат с нероли без ванили"
```

Посмотреть разбор запроса отдельно от тяжёлой embedding-модели:

```powershell
scentmatch-parse-intent "Лучшие мужские ароматы на лето"
```

Команда по умолчанию использует fine-tuned E5 вместе с community ranker и
применяет прозрачный фильтр явных отрицаний (`без ванили`, `без табака` и т. п.).

Поиск также распознаёт русские и английские названия ароматов внутри свободного
запроса и умеет искать более доступные аналоги:

```powershell
scentmatch-search "аромат похожий на Bleu de Chanel, но бюджетнее"
scentmatch-search "Something like Dior Sauvage, but cheaper and less spicy"
```

Для таких запросов система независимо учитывает embedding запроса, embedding
референса, голосованные связи `smells-like`, `also-liked`, дополнительные
ограничения и popularity. Сам референс исключается. Выводимые цены — это
исторический снимок объявлений eBay за май 2024 года, а не актуальная цена.

Старый review-reranker сохранён только как эксперимент: 9 050 обезличенных
отзывов для 647 ароматов представлены 1 461 embedding-чанком. Он не умеет
различать положительные и отрицательные утверждения, поэтому выключен по
умолчанию. Для отдельного эксперимента:

```powershell
scentmatch-search "аромат похожий на Bleu de Chanel" --review-rerank
```

Review-пилот, источник, фильтры и ограничения описаны в
[`review_retrieval.md`](review_retrieval.md).

Подробности, ограничения источников и план эксперимента с настоящими текстами
отзывов описаны в
[`reference_and_community_retrieval.md`](reference_and_community_retrieval.md).

Fine-tuning запускается на бесплатной GPU в
[`notebooks/finetune_e5_colab.ipynb`](../notebooks/finetune_e5_colab.ipynb).
Устройство training dataset описано в
[`training_dataset.md`](training_dataset.md).
