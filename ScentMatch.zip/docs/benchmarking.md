# CPU benchmark protocol

## Goal

Measure reproducible application performance on the actual target laptop rather
than copying numbers from a cloud runner or a different CPU.

## Command

From the project root with the virtual environment activated:

```powershell
scentmatch-runtime-check
scentmatch-benchmark --repeats 3 --warmup 2 --top-k 5
```

The workload uses all 48 queries from
`data/eval/ranking_queries_v3.jsonl`, shuffles 144 measured calls with seed 42,
and preserves query categories for grouped reporting.

The fixed set contains:

| Category | Unique queries | What it checks |
| --- | ---: | --- |
| season | 6 | summer, winter, spring and autumn preferences |
| occasion | 6 | office, date, everyday use, wedding and holiday |
| performance | 4 | longevity and sillage |
| exclusion | 4 | excluded notes or accords |
| attributes | 4 | desired notes and accords |
| popularity | 4 | well-known/popular preference |
| reference | 10 | similarity to a named fragrance, including a typo |
| complex | 6 | several simultaneous constraints |
| negative control | 4 | vague or underspecified requests |

Each query is measured three times, producing 144 sequential calls. Two calls
before the measured workload warm the already loaded service. The workload is
not generated during the benchmark and does not call an external LLM.

This benchmark measures performance only. Ranking quality, intent accuracy and
link-prediction metrics come from the separate evaluation protocols described
in [`metrics.md`](metrics.md).

## Measured values

- service/model load time;
- RSS before and after model load;
- warm inference mean, p50, p95 and p99;
- throughput in queries per second;
- latency by category;
- reference versus non-reference latency;
- peak process RSS sampled every 10 ms;
- OS, Python, logical CPU count and total RAM.

The timed region is `RecommendationService.recommend`. It excludes HTTP
transport and includes query encoding, intent/reference resolution, ranking,
link prediction when applicable, diversity and explanation generation.

## Fair-run checklist

1. Close model-heavy applications and previous ScentMatch processes.
2. Keep the laptop connected to power and use the normal performance profile.
3. Do not run the benchmark inside an IDE debugger.
4. Run the command once; do not select the best of several runs.
5. Preserve the generated JSON without manually editing values.
6. Record whether the run is native Windows or Docker; do not mix them.

## Output

```text
artifacts/benchmark_v1/benchmark_report.json
artifacts/benchmark_v1/benchmark_report.md
```

Send both files for the final README update. The public result should include the
hardware/OS line and explicitly label latency as warm in-process inference.

## Quick smoke mode

This checks that the command works but must not be published as a benchmark:

```powershell
scentmatch-benchmark --limit 3 --repeats 1 --warmup 1
```
