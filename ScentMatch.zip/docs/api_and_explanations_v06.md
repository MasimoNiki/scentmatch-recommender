# ScentMatch v0.6: API and evidence-based explanations

## Design goal

The application layer must not change ranking or invent perfume properties.
`RecommendationService` is the only public inference entry point used by the
CLI, FastAPI and Gradio demo. It enriches ranker output with deterministic
explanations but does not call a generative LLM.

## Runtime flow

```text
query
  -> QueryIntent + reference resolution
  -> fine-tuned E5 and structured/community features
  -> optional link-prediction score for reference queries
  -> constraints and diversity
  -> ExplanationGenerator
  -> CLI / REST API / Gradio
```

The E5 model, embeddings, community feature store and portable link predictor
are loaded once when the service starts.

## Explanation contract

Each recommendation contains:

- `why_recommended`: up to four typed reasons;
- `possible_drawbacks`: vote-backed community summary items;
- `evidence_level`: `high`, `medium` or `limited`;
- raw `components` and active `weights` for technical audit.

A reason is emitted only when its source component exists. For example,
`ml_similarity` cannot appear when `link_prediction` is missing, and
`community_similarity` requires a positive `reminds_me_of` signal.

`evidence_level` describes the amount of available evidence, not an objective
probability that a person will like the fragrance.

Community pros and cons in the current dataset are source-provided AI summaries
retained only when backed by user votes. The UI labels them as community
summaries and preserves their original English text, agreement and vote count.

## REST endpoints

| Method | Path | Purpose |
| --- | --- | --- |
| `GET` | `/health` | readiness and catalogue size |
| `GET` | `/api/v1/info` | model and service metadata |
| `POST` | `/api/v1/recommend` | recommendations with explanations |
| `GET` | `/api/v1/perfumes/{id}` | catalogue and community profile |

`POST /api/v1/recommend` accepts:

```json
{
  "query": "Стойкий свежий аромат на лето без сильного шлейфа",
  "top_k": 5
}
```

Input is limited to 500 characters and `top_k` is limited to 1–10. CPU-bound
inference runs outside the async event loop.

## Known limitations

- similarity and community perception are subjective;
- free-form ranking does not yet have a large expert-judged test set;
- link prediction is used only for resolved reference queries;
- price data is historical and must not be presented as live availability;
- source licences restrict the current build to non-commercial research and
  portfolio use.
