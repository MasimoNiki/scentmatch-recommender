# Screenshot assets

- `demo_reference.png`: real Windows reference-aware run;
- `demo_constraints.png`: real Windows constraint-only run;
- `api_docs.png`: successful Swagger request with a `200` response.

Capture requirements are documented in `../screenshots/README.md`.
