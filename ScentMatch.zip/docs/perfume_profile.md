# Формат `perfume_profile`

`perfume_profile` — единый документ аромата, который позже станет документом
для retrieval. Текущая версия схемы — `1.0`.

```json
{
  "schema_version": "1.0",
  "perfume_id": "74630",
  "name": "Example",
  "brand": "Example Brand",
  "source_url": "https://www.fragrantica.com/perfume/...-74630.html",
  "gender": "unisex",
  "country": "France",
  "year": 2022,
  "rating": {"value": 4.12, "count": 381},
  "perfumers": ["Perfumer Name"],
  "accords": ["woody", "amber", "warm spicy"],
  "notes": {
    "top": ["Bergamot"],
    "middle": ["Rose"],
    "base": ["Sandalwood"]
  },
  "source_description": "Source description...",
  "retrieval_text": "Example by Example Brand. ..."
}
```

## Решения по полям

- `perfume_id` берётся из URL Fragrantica и хранится строкой.
- Ноты остаются разделёнными на `top`, `middle`, `base`; это важная часть
  исходных данных и будущего обучения.
- `accords` сохраняют исходный порядок: первый элемент является главным.
- `null` используется для действительно неизвестных одиночных значений, а
  пустой список — для неизвестного набора значений.
- `source_description` сохраняется отдельно от составленного текста, чтобы
  происхождение данных оставалось прозрачным.
- `retrieval_text` строится детерминированно. Embeddings на этом этапе не
  создаются.
- Точный повтор одной ноты внутри одного слоя удаляется с сохранением первого
  появления. Похожие, но не идентичные термины не объединяются автоматически.

Машиночитаемая схема находится в `schemas/perfume_profile.schema.json`.
