# Fine-tuning results v1

Модель `intfloat/multilingual-e5-small` дообучена на 2 000 synthetic train
n-tuples с тремя hard negatives. Validation содержит 200 непересекающихся
positive-парфюмов. Evaluation-запросы при обучении не использовались.

## Test split: 20 запросов

| Метрика | Baseline | Fine-tuned | Fine-tuned + exclusions |
|---|---:|---:|---:|
| Precision@5 | 0,310 | 0,530 | **0,600** |
| Precision@10 | 0,270 | 0,510 | **0,560** |
| HitRate@5 | 0,700 | 0,850 | **0,950** |
| HitRate@10 | 0,800 | 0,900 | **0,950** |
| MRR@10 | 0,525 | 0,658 | **0,783** |
| nDCG@10 | 0,217 | 0,368 | **0,412** |

Метрики являются proxy-оценками относительно автоматических silver labels.
Они полезны для сравнения версий, но не измеряют субъективное восприятие запаха.

## Анализ по запросам

Raw fine-tuned модель улучшила nDCG@10 на 30 из 40 запросов. После добавления
детерминированного фильтра явных отрицаний улучшены 36 запросов, ухудшены 4.

Средний прирост nDCG@10 относительно baseline по категориям:

- `note`: +0,313;
- `accord`: +0,220;
- `negation`: +0,187;
- `composition`: +0,181;
- `season`: +0,178;
- `occasion`: −0,037.

Слабое место — субъективные запросы о ситуации использования. Это ожидаемо:
training data основаны в основном на нотах и аккордах. Следующая итерация может
добавить occasion-oriented synthetic queries или небольшой human-labeled набор.

## Hybrid inference

Обычный dense retrieval плохо соблюдал явные конструкции вроде `без ванили`.
Inference теперь извлекает только явно названные запреты из фрагментов `без …`
и `исключить …`, затем удаляет нарушающие их документы из расширенного top-k.
Другие свойства запроса остаются задачей embedding-модели.

Такой фильтр прозрачен, воспроизводим и не пытается заменить NLP-модель общим
набором ручных правил.

## Артефакты

- `models/e5_finetuned/` — сохранённая fine-tuned модель;
- `artifacts/e5_finetuned/document_embeddings.npy` — матрица `5000 × 384`;
- `data/interim/e5_finetuned_report.json` — raw fine-tuned метрики;
- `data/interim/e5_finetuned_hybrid_report.json` — итоговые hybrid-метрики;
- `data/interim/model_comparison_hybrid.csv` — сравнение каждого запроса;
- `models/e5_finetuned/model_manifest.json` — версия и SHA-256 весов.
