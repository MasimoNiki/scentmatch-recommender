# Metrics and evaluation provenance

This document is the canonical public summary for ScentMatch v0.7. It separates
verified component metrics from proxy retrieval scores and subjective product
quality.

## Query understanding

Source: `data/interim/evaluation_v2_report.json`.

| Metric | Value | Cases |
| --- | ---: | ---: |
| Intent case accuracy | 1.000 | 18 |
| Intent field accuracy | 1.000 | 18 |
| Reference Top-1 accuracy | 1.000 | 15 positive |
| Reference abstention accuracy | 1.000 | 5 negative/ambiguous |

The set is curated and small. These results are regression evidence, not a claim
that every possible natural-language formulation is understood.

## Community similarity link prediction

Canonical source: `artifacts/link_predictor_v1/model.json`.

SHA-256:

```text
05e76ee7b4f7b2bef641c7d34a5a176107170ee3ea12173e921a7bea14519095
```

Labels use only observed vote-backed pairs:

- positive: at least 10 votes and agreement >= 0.70;
- negative: at least 10 votes and agreement <= 0.40;
- unobserved/missing pairs are not negatives.

| Metric | Dev | Test |
| --- | ---: | ---: |
| ROC-AUC | 0.840 | **0.883** |
| Average Precision | 0.756 | **0.790** |
| E5 macro pairwise accuracy | 0.803 | 0.709 |
| ML macro pairwise accuracy | **0.947** | **0.894** |
| E5 top-1 positive rate | 0.800 | 0.688 |
| ML top-1 positive rate | **0.938** | **0.896** |

The test classification set contains 893 observed pairs, including 200 positive
pairs. Pairwise ranking contains 96 reference groups and 158 positive-negative
comparisons.

### Leakage control

- directed entries are canonicalized into one undirected pair before splitting;
- dev/test positive edges are absent from common-neighbor graph features;
- split selection is deterministic;
- node degree was removed before final test inspection after dev ablation exposed
  hub bias;
- test metrics are not used for selecting regularization or features.

## Community data coverage

Source: `data/interim/community_profiles_v2_report.json`.

| Statistic | Value |
| --- | ---: |
| Selected catalogue | 5,000 |
| Matched community profiles | 5,000 (100%) |
| `reminds_me_of` edges in catalogue | 27,804 |
| `also_liked` edges in catalogue | 70,956 |
| Profiles with vote-backed pros | 4,199 |
| Profiles with vote-backed cons | 3,324 |

## Proxy retrieval metrics

The earlier E5 retrieval report uses automatically generated silver qrels. Its
test Hit@5 is 0.95 and MRR@10 is 0.783, but these values are deliberately not
promoted as primary portfolio metrics: silver relevance labels can reward the
same rules used to generate them.

## What is not measured yet

- expert-judged NDCG for unrestricted free-form recommendations;
- online click, save or purchase feedback;
- individual preference calibration;
- cross-domain/store availability quality.

The CPU latency/RAM benchmark is separate because it depends on hardware. See
[`benchmarking.md`](benchmarking.md).

## Stale local report warning

Some earlier project copies contain
`data/interim/link_prediction_v1_report.json` from the rejected degree-feature
experiment. It is not a canonical v0.7 source. The portable model artifact and
this document describe the final no-degree model.
