# Evaluation v2: intent и reference resolution

## Зачем нужен отдельный этап

Общая retrieval-метрика не объясняет, почему рекомендация ошиблась. В ScentMatch
v2 сначала отдельно проверяются два компонента, не требующие новых внешних данных:

1. разбор запроса в QueryIntent;
2. определение названного пользователем референсного аромата.

Команда:

    scentmatch-eval-v2

создаёт data/interim/evaluation_v2_report.json.

## Наборы

- data/eval/query_intent_v2.jsonl — 18 составных русских и английских
  запросов. Для каждого указаны только поля, которые в нём явно проверяются.
- data/eval/reference_resolution_v2.jsonl — 20 запросов: точные названия,
  варианты, опечатки и отрицательные примеры, на которых resolver обязан
  отказаться от угадывания.

Эти наборы являются инженерными regression tests, а не человеческой оценкой
качества рекомендаций.

## Метрики и quality gates

- intent.field_accuracy — доля правильно извлечённых проверяемых полей;
- intent.case_accuracy — доля запросов без ошибок ни в одном размеченном поле;
- reference.top1_accuracy — точность accepted reference на положительных
  примерах;
- reference.abstain_accuracy — доля корректных отказов на неоднозначных и
  нереференсных запросах.

Текущие gates:

    intent field accuracy >= 0.90
    reference Top-1 accuracy >= 0.95
    reference abstain accuracy = 1.00

## Что эта оценка пока не доказывает

Она не проверяет релевантность top-5, соответствие сезону, доступность в
магазинах или мнение пользователей. Для этого нужны:

1. community votes по season/day-night/longevity/sillage;
2. pooled candidates от нескольких ranking-версий;
3. ручная разметка top-10 по единой шкале;
4. метрики nDCG@5, constraint violations@5, mismatch rate и diversity.
