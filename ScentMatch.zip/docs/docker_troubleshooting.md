# Docker Desktop: PyPI SSL/TLS troubleshooting

## Symptom

The build fails while requesting `https://pypi.org/simple/...` with
`SSLEOFError` or another TLS error. A later message such as “No matching
distribution found for setuptools” is misleading: pip received no package
index response, so it saw zero available versions.

This happens before ScentMatch is installed. It is a Docker container outbound
network, proxy, VPN or HTTPS-inspection issue.

## 1. Test access from a clean container

Run in PowerShell:

```powershell
docker run --rm python:3.11-slim-bookworm python -c "import urllib.request; print(urllib.request.urlopen('https://pypi.org/simple/setuptools/', timeout=20).status)"
```

Expected output:

```text
200
```

Also verify DNS if the first command fails:

```powershell
docker run --rm python:3.11-slim-bookworm python -c "import socket; print(socket.getaddrinfo('pypi.org', 443))"
```

- DNS failure means Docker Desktop cannot resolve the host.
- DNS success followed by TLS EOF points to a proxy, VPN, firewall or HTTPS
  inspection between the container and PyPI.

## 2. Check Docker Desktop networking

Open **Docker Desktop → Settings → Resources → Proxies**.

- If Windows uses a proxy, choose the system proxy or enter the same proxy
  manually.
- If Windows does not use a proxy, remove a stale manual proxy configuration.
- Apply the change and restart Docker Desktop.
- If a VPN is active, reconnect it after Docker Desktop starts or briefly test
  without it.
- If security software performs HTTPS inspection, do not bypass TLS validation
  with pip `--trusted-host`. Configure the trusted root CA for Docker instead.

Do not paste proxy credentials into an issue, README, Dockerfile or build log.

## 3. Re-test and build

After the clean-container command returns `200`:

```powershell
docker compose build --no-cache --progress=plain
docker compose up
```

The Dockerfile uses a stable Debian base tag, longer pip timeout/retries, a
BuildKit pip cache, and installs the declared build backend once before using
`--no-build-isolation`. These settings make transient downloads less fragile,
but they cannot repair a blocked TLS connection.

The full local image installs `torch` first from the official CPU-only PyTorch
index. This prevents pip from selecting Linux CUDA/NVIDIA runtime packages on a
machine where GPU inference is neither available nor required. CI sets
`INSTALL_INFERENCE=0` because model weights are intentionally absent there.

After testing the application, stop it with `docker compose down`. The Compose
service has no automatic restart policy. To remove only the ScentMatch image:

```powershell
docker image rm scentmatch:0.7.0
```

## 4. Information to collect if it still fails

```powershell
docker version
docker info | Select-String -Pattern "Proxy|DNS"
```

Record the result of the clean-container HTTPS test as well. Redact proxy URLs
if they contain a username, password, token or internal hostname.
