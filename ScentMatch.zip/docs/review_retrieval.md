# Review retrieval pilot

## Source decision

The pilot uses the public
[SentimentDrivenCommunityDetection](https://github.com/Kalashi-Saed-Collaborations/SentimentDrivenCommunityDetection)
dataset. It contains 36,434 Persian comments for 1,369 perfumes, perfume and brand
names, and ratings for scent, longevity, sillage and bottle design.

The repository is MIT-licensed, while its README additionally requests academic and
non-commercial use with attribution. ScentMatch follows the stricter README terms.
The review experiment must therefore be treated as a non-commercial portfolio and
research component.

## Automated preparation

The command below reproduces the preparation when the original JSON is available:

```powershell
scentmatch-prepare-reviews --source path\to\atrafshan_data.json
```

The pipeline:

1. Joins only a unique exact normalized `brand + perfume name` pair.
2. Drops replies, texts shorter than 40 characters and known scent votes below 5.
3. Removes user IDs and usernames.
4. Deduplicates texts and keeps up to nine informative reviews per perfume.
5. Produces up to three review chunks per perfume.

Result:

- 19,080 source reviews matched before quality filtering;
- 9,050 eligible standalone reviews;
- 647 catalog perfumes;
- 1,461 review chunks.

## Review embeddings

```powershell
scentmatch-review-index build
```

The same fine-tuned multilingual E5 model encodes the Persian chunks. The resulting
matrix is only about 2.2 MB and is included in the project. Building it took about
five minutes on the reference Windows CPU, but normal search does not rebuild it.

## Hybrid reranking

Catalog retrieval remains the first stage. For the 647 covered perfumes, the best
review-chunk similarity is standardized within the review corpus and contributes a
small capped score adjustment. Perfumes without review coverage receive no bonus or
penalty. This avoids comparing raw catalog and review cosine scores as if their
scales were identical.

Named-reference queries use the reference review vector when it exists. Explicit
Russian and English notes/accords are also applied as a deterministic preference
bonus, while exclusions remain hard filters.

Review reranking is enabled by default. A/B comparison is available with:

```powershell
scentmatch-search "аромат похожий на Bleu de Chanel, но бюджетнее"
scentmatch-search "аромат похожий на Bleu de Chanel, но бюджетнее" --no-review-rerank
```

## Current evidence and limitations

For the Bleu de Chanel budget query, `Tag Him — Armaf` stays at rank 1. Its matched
reviews explicitly describe it as a lower-cost Bleu de Chanel EDT alternative, so
the result now has independent community evidence rather than notes alone.

This is still a pilot, not proof of a general quality gain:

- review coverage is 647 of 5,000 catalog perfumes;
- the reviews are Persian, while user queries are mainly Russian or English;
- multilingual similarity was smoke-tested, but no bilingual human relevance set
  exists yet;
- price values remain a May 2024 marketplace snapshot.

The next evaluation step should add 15–20 bilingual human-judged queries and compare
catalog-only versus review-hybrid nDCG and MRR. The review layer should remain
optional until that comparison is complete.
